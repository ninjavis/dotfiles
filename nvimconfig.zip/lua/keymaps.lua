-- CUSTOM KEYMAPS
local keymap = vim.keymap
local opts = { noremap = true, silent = true }

-- Set <leader>
keymap.set("n", "<Space>", "")
vim.g.mapleader = " "
vim.g.maplocalleader = " "

-- Remap <esc>
keymap.set("i", "jj", "<esc>")

-- Enter command mode quicker
keymap.set({ "n", "v" }, ";", ":")

-- Window Navigation
-- keymap.set('n', '<m-h>', '<C-w>h') -- jump window left
-- keymap.set('n', '<m-l>', '<C-w>l') -- jump window right
-- keymap.set('n', '<m-k>', '<C-w>k') -- jump window up
-- keymap.set('n', '<m-j>', '<C-w>j') -- jump window down
keymap.set("n", "<left>", "<C-w>h") -- jump window left
keymap.set("n", "<right>", "<C-w>l") -- jump window right
keymap.set("n", "<up>", "<C-w>k") -- jump window up
keymap.set("n", "<down>", "<C-w>j") -- jump window down

-- Split screens
keymap.set("n", "ss", ":split<CR>") -- split screen horizontally
keymap.set("n", "vs", ":vsplit<CR>") -- split screen vertically

-- Center screen on search word/next/prev
keymap.set("n", "n", "nzz")
keymap.set("n", "N", "Nzz")
keymap.set("n", "*", "*zz")
keymap.set("n", "#", "#zz")
keymap.set("n", "gd", "gdzz")

-- Save Buffer
keymap.set("n", "<C-s>", ":w<CR>") -- save file with CTRL+s
-- keymap.set('i', '<C-s>', '<esc>:w<CR>a') -- save file when in insert mode then return to insert mode
keymap.set("i", "<C-s>", "<esc>:w<CR>") -- exit insert mode then save file
keymap.set("v", "<C-s>", "<esc>:w<CR>") -- exit visual mode then save file

-- Manipulate lines
keymap.set("n", "<A-K>", ":m .-2<CR>==") -- move line up(n)
keymap.set("n", "<A-J>", ":m .+1<CR>==") -- move line down(n)
keymap.set("v", "<A-K>", ":m '<-2<CR>gv=gv") -- move line/selection up(v)
keymap.set("v", "<A-J>", ":m '>+1<CR>gv=gv") -- move line/selection down (v)

keymap.set({ "n", "v" }, "<A-j>", ":co.<CR>") -- duplicate line down
keymap.set("i", "<A-,>", "<BS>") -- Alt + comma to backspace(i)
keymap.set("i", "<A-.>", "<del>") -- Alt + fullstop to delete(i)
-- delete single character without copying into register
keymap.set("n", "x", '"_x', opts)

-- Stay in indent mode and visual mode after indenting
keymap.set("v", ">", ">gv")
keymap.set("v", "<", "<gv")

-- Keep Copied value after replacing with pasted value
keymap.set("x", "p", '[["_dP]]')
keymap.set("n", ",p", '"0p')
keymap.set("n", ",P", '"0P')

-- Remap <C-/> to the same as <C-z>, which minimizes the active nvim instance.
keymap.set({ "n", "v", "x", "o" }, "<C-\\>", "<C-z>")

-- AUTOCOMPLETE SUGGESTIONS
-- intercept Enter key if autocomplete menu is open so that cursor does not jump to next line after selecting suggestion.
-- keymap.set('i', '<CR>', function()
--   if vim.fn.pumvisible() ~= 0 then
--     return '<C-y>'
--   else
--     return '<CR>'
--   end
-- end, { expr = true, noremap = true })

-- Navigate autosuggestions down with Ctrl+j
-- vim.keymap.set('i', '<C-j>', function()
--   if vim.fn.pumvisible() ~= 0 then
--     return '<C-n>'
--   else
--     return '<C-j>'
--   end
-- end, { expr = true, noremap = true })

-- Navigate autosuggestions up with Ctrl+k
-- vim.keymap.set('i', '<C-k>', function()
--   if vim.fn.pumvisible() ~= 0 then
--     return '<C-p>'
--   else
--     return '<C-k>'
--   end
-- end, { expr = true, noremap = true })

-- Bufferline
keymap.set("n", "<S-h>", "<cmd>BufferLineCyclePrev<cr>")
keymap.set("n", "<S-l>", "<cmd>BufferLineCycleNext<cr>")
keymap.set("n", "<A-h>", "<cmd>BufferLineMovePrev<cr>")
keymap.set("n", "<A-l>", "<cmd>BufferLineMoveNext<cr>")
-- { "<leader>bp", "<Cmd>BufferLineTogglePin<CR>", desc = "Toggle pin" },
-- { "<leader>bP", "<Cmd>BufferLineGroupClose ungrouped<CR>", desc = "Delete non-pinned buffers" },
-- { "<leader>bo", "<Cmd>BufferLineCloseOthers<CR>", desc = "Delete other buffers" },
-- { "<leader>br", "<Cmd>BufferLineCloseRight<CR>", desc = "Delete buffers to the right" },
-- { "<leader>bl", "<Cmd>BufferLineCloseLeft<CR>", desc = "Delete buffers to the left" },

-- Nvim-tree
keymap.set("n", "<leader>ee", "<cmd>NvimTreeToggle<CR>", { desc = "Toggle file explorer" }) -- toggle file explorer
keymap.set("n", "<leader>ef", "<cmd>NvimTreeFindFileToggle<CR>", { desc = "Toggle file explorer on current file" }) -- toggle file explorer on current file
keymap.set("n", "<leader>ec", "<cmd>NvimTreeCollapse<CR>", { desc = "Collapse file explorer" }) -- collapse file explorer
keymap.set("n", "<leader>er", "<cmd>NvimTreeRefresh<CR>", { desc = "Refresh file explorer" }) -- refresh file explorer

-- Resize Nvim Tree width
keymap.set('n', '<leader>eg', ':NvimTreeResize 100<CR>', { noremap = true, silent = true })
keymap.set('n', '<leader>es', ':NvimTreeResize 35<CR>', { noremap = true, silent = true })


-- NEOVIDE SPECIFIC
-- Enable zoom in/out
-- if vim.g.neovide == true then
-- 	vim.api.nvim_set_keymap(
-- 		"n",
-- 		"<C-=>",
-- 		":lua vim.g.neovide_scale_factor = math.min(vim.g.neovide_scale_factor + 0.1,  1.0)<CR>",
-- 		{ silent = true }
-- 	)
-- 	vim.api.nvim_set_keymap(
-- 		"n",
-- 		"<C-->",
-- 		":lua vim.g.neovide_scale_factor = math.max(vim.g.neovide_scale_factor - 0.1,  0.1)<CR>",
-- 		{ silent = true }
-- 	)
-- 	vim.api.nvim_set_keymap(
-- 		"n",
-- 		"<C-+>",
-- 		":lua vim.g.neovide_transparency = math.min(vim.g.neovide_transparency + 0.05, 1.0)<CR>",
-- 		{ silent = true }
-- 	)
-- 	vim.api.nvim_set_keymap(
-- 		"n",
-- 		"<C-_>",
-- 		":lua vim.g.neovide_transparency = math.max(vim.g.neovide_transparency - 0.05, 0.0)<CR>",
-- 		{ silent = true }
-- 	)
-- 	vim.api.nvim_set_keymap("n", "<C-0>", ":lua vim.g.neovide_scale_factor = 0.5<CR>", { silent = true })
-- 	vim.api.nvim_set_keymap("n", "<C-)>", ":lua vim.g.neovide_transparency = 0.9<CR>", { silent = true })
-- end

-- local function toggle_adaptive_size()
--   return "<cmd>lua require('nvim-tree.view').View.adaptive_size = not require('nvim-tree.view').View.adaptive_size"
-- end
--
-- keymap.set('n', '<leader>a', toggle_adaptive_size()'<CR>')

-- local function avcw(func)
-- return "<Cmd>lua require('nvim-tree.view').adaptive_size = not require('nvim-tree.view').adaptive_size<CR>"
-- end

-- keymap.set('n', '<leader>a', avcw())

-- local currentSize = require('nvim-tree.view').view.adaptive_size;

-- local sizer = require('nvim-tree.view').adaptive_size = not require('nvim-tree.view').adaptive_size;
-- local tele = "require('telescope.builtin')"

-- local function disp()
-- print( currentSize)
-- end

-- keymap.set('n', '<leader>a', disp()'<cr>')
